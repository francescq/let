export const GAME = 'GAME'
export const DEFEAT = 'DEFEAT'
export const VICTORY = 'VICTORY'
